import { bookInfo } from '../../app/bookInfo';
export const MYBOOKS: bookInfo[] = 
[
    { bname: '2 States',  bauthor: 'Chetan Bhagat', bgenre: "Novel", byear: '2001' } ,
    { bname: 'Half Girlfriend',  bauthor: 'Chetan Bhagat', bgenre: "Love Story", byear: '1999' },
    { bname: 'The Home and the World',  bauthor: 'Ravindranath Tagore', bgenre: "Novel", byear: '1906'},
    { bname: 'Gitanjali',  bauthor: 'Ravindranath Tagore', bgenre: "Biography", byear: '1880'}
]