import { bookInfo } from '../../app/bookInfo';
export const MYBOOKS: bookInfo[] = 
[
    { bname: '2 States',  bauthor: 'Chetan Bhagat', bgenre: "Novel", byear: '2001' , bpic: "assets/Images/book1.jpg" } ,
    { bname: 'Half Girlfriend',  bauthor: 'Chetan Bhagat', bgenre: "Love Story", byear: '1999' , bpic: "assets/Images/book2.jpg" },
    { bname: 'The Home and the World',  bauthor: 'Ravindranath Tagore', bgenre: "Novel", byear: '1906' , bpic: "assets/Images/book3.jpg"},
    { bname: 'Gitanjali',  bauthor: 'Ravindranath Tagore', bgenre: "Biography", byear: '1880' , bpic: "assets/Images/book4.jpg" }
]