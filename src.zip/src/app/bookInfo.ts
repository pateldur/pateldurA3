export class bookInfo {
    bname: string;
    bauthor: string;
    bgenre : string;
    byear: string; 
    bpic: string;
}