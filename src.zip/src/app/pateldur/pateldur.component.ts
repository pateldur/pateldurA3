import { Component, OnInit } from '@angular/core';

import {MYBOOKS} from 'src/assets/data/myBooks';
import { bookInfo } from '../BookInfo';

@Component({
  selector: 'app-pateldur',
  templateUrl: './pateldur.component.html',
  styleUrls: ['./pateldur.component.css']
})
export class PateldurComponent implements OnInit {

  myBooks = MYBOOKS;
  classPicked: bookInfo;
  

  constructor() { }

  ngOnInit() {
    this.onButtonClick(0);
    
  }


  ngAfterViewInit() {
    var divs = document.getElementById("myList").getElementsByTagName("div");
    for (let x=0; x < divs.length; x++) {
      divs[x].style.display = "none";
    }
  }

  onClickMe(index) {
    var divs = document.getElementById("myList").getElementsByTagName("div");

    if (divs[index].style.display == 'none'){
      divs[index].style.display = 'block';
    } 
    else {
      divs[index].style.display = 'none';
    }  
  }

  onButtonClick(index){
    this.classPicked = {
      bname: this.myBooks[index].bname,
      bauthor: this.myBooks[index].bauthor,   
      bgenre: this.myBooks[index].bgenre,
      byear: this.myBooks[index].byear, 
      bpic: this.myBooks[index].bpic   
    }
  }
}

