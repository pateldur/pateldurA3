import { Component, OnInit } from '@angular/core';
import { pateldur } from '../pateldur';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {

  
   bio: pateldur = {
    pid: "991500201", pname: "Durva Patel", pcampus: "Davis", 
    plogin: "pateldur", passignTitle: "Assignment-3"
  }


  constructor() { }

  ngOnInit() {
  }

}
