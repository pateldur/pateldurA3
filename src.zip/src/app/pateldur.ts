export class pateldur {

pid: string;
pname: string;
pcampus: string;
plogin: string;
passignTitle: string;

}