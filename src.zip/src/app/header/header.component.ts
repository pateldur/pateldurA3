import { Component, OnInit } from '@angular/core';
import { pateldur } from '../pateldur';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

 
  bio: pateldur = {
    pid: "991500201", pname: "Durva Patel", pcampus: "Davis", 
    plogin: "pateldur", passignTitle: "Assignment-3"
    
  }
  
  constructor() { }

  ngOnInit() {
  }

}
